create table smallCategory(
	smallcode char(3) not null,
	smallname varchar2(20) not null,
	bigcode char(3) not null,
	primary key(smallcode)
);

insert into smallCategory values('100', '소설/시', '100');
insert into smallCategory values('200', '인문', '100');
insert into smallCategory values('300', '예술', '100');
insert into smallCategory values('400', '사회', '100');
insert into smallCategory values('500', 'IT모바일', '100');
insert into smallCategory values('600', 'ELT사전', '200');
insert into smallCategory values('700', '문학/소설', '200');
insert into smallCategory values('800', '경제/경영', '200');

select * from smallCategory;

create table books(
	book_id number(3) not null,
	book_name varchar2(40) not null,
	book_price number not null,
	book_stock number not null,
	book_discount number not null,
	book_type varchar2(20) not null,
	book_content varchar2(255) not null,
	book_regdate date,
	smallcode char(3) not null,
	primary key(book_id),
	foreign key(smallcode) references smallCategory(smallcode) ON DELETE cascade
);

create sequence books_seq start with 101 increment by 1 nocycle;

insert into books values(books_seq.nextval, '이것이 자바다', 25000, 10, 10, 'NEW', '이것이 자바다 도서는..', '23/12/26', '500');
insert into books values(books_seq.nextval, '자바의 정석', 30000, 5, 20, 'NORMAL', '자바의 정석 도서는', '23/12/26', '500');
insert into books values(books_seq.nextval, '명견만리', 12000, 5, 20, 'BEST', 'KBS 명견만리 제작진이...', '23/12/29', '200');
insert into books values(books_seq.nextval, '콜린스, 코빌드 영어 사전', 99000, 5, 10, 'BEST', '콜린스 코빌드 영어 사전은 옥스포드..', '23/12/29', '600');
insert into books values(books_seq.nextval, '황순원의 소나기', 1000, 100, 10, 'NORMAL', '교육부 권장도서. 황순원의 소나기', '23/12/29', '700');

select * from books;

commit;