function frmCheck() {
	let book_name  = document.querySelector("input[name=book_name]");
	let book_price  = document.querySelector("input[name=book_price]");
	let book_stock  = document.querySelector("input[name=book_stock]");
	let book_content  = document.querySelector("textarea[name=book_content]");
	
	if(book_name.value == "") {
		alert("도서명을 입력하세요.");
		book_name.focus();
		return false;
	}
	if(book_price.value == "") {
		alert("가격을 입력하세요.");
		book_price.focus();
		return false;
	}
	if(book_stock.value == "") {
		alert("재고를 입력하세요.");
		book_stock.focus();
		return false;
	}
	if(book_content.value == "") {
		alert("도서내용을 입력하세요.");
		book_content.focus();
		return false;
	}
}