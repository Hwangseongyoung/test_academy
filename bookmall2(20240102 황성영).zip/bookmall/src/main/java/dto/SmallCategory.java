package dto;

public class SmallCategory {
	private String smallcode;
	private String smallname;
	private String bigcode;
	
	public String getSmallcode() {
		return smallcode;
	}
	public void setSmallcode(String smallcode) {
		this.smallcode = smallcode;
	}
	public String getSmallname() {
		return smallname;
	}
	public void setSmallname(String smallname) {
		this.smallname = smallname;
	}
	public String getBigcode() {
		return bigcode;
	}
	public void setBigcode(String bigcode) {
		this.bigcode = bigcode;
	}
}
