package dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.*;

import dto.SmallCategory;
import dto.Book;

public class BookDao {
	
	Connection conn = null;
	PreparedStatement pstmt = null;
	ResultSet rs = null;
	
	List<SmallCategory> sList = new ArrayList<SmallCategory>();
	List<Book> bList = new ArrayList<Book>();
	
	public static Connection getConnetion() throws Exception {
		Class.forName("oracle.jdbc.OracleDriver");
		Connection conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe", "system", "1234");		
		return conn;		
	}
	
	public int nextBookId() throws Exception {
		conn = getConnetion();
		String sql = "select NVL(max(book_id)+1, 101) FROM books";
		pstmt = conn.prepareStatement(sql);
		rs = pstmt.executeQuery();
		
		int book_id = 0;
		if(rs.next()) {
			book_id = rs.getInt(1);
		}
		
		return book_id;
	}
	
	public List<SmallCategory> getSmallCategoryAll() throws Exception {
		conn = getConnetion();
		String sql = "select * from smallCategory";
		pstmt = conn.prepareStatement(sql);
		rs = pstmt.executeQuery();
		
		if(rs.next()) {
			do {
				SmallCategory sc = new SmallCategory();
				sc.setSmallcode(rs.getString(1));
				sc.setSmallname(rs.getString(2));
				sc.setBigcode(rs.getString(3));
				
				sList.add(sc);
				
			}while(rs.next());
		}
		
		return sList;
	}
	
	public int insertBook(Book book) throws Exception {
		conn = getConnetion();
		String sql = "insert into books values(?, ?, ?, ?, ?, ?, ?, sysdate, ?)";
		pstmt = conn.prepareStatement(sql);
		
		pstmt.setInt(1, book.getBook_id());
		pstmt.setString(2, book.getBook_name());
		pstmt.setInt(3, book.getBook_price());
		pstmt.setInt(4, book.getBook_stock());
		pstmt.setInt(5, book.getBook_discount());
		pstmt.setString(6, book.getBook_type());
		pstmt.setString(7, book.getBook_content());
		pstmt.setString(8, book.getSmallcode());
		int row = pstmt.executeUpdate();
		
		return row;
	}
	
	public List<Book> getBookAll() throws Exception {
		conn = getConnetion();
		
		String sql = "select * from books order by book_id desc";
		pstmt = conn.prepareStatement(sql);
		rs = pstmt.executeQuery();
		
		if(rs.next()) {
			do {			
				Book book = new Book();
				book.setBook_id(rs.getInt(1));;
				book.setBook_name(rs.getString(2));
				book.setBook_price(rs.getInt(3));
				book.setBook_stock(rs.getInt(4));
				book.setBook_discount(rs.getInt(5));
				book.setBook_type(rs.getString(6));
				book.setBook_content(rs.getString(7));
				book.setBook_regdate(rs.getString(8));
				book.setSmallcode(rs.getString(9));
				
				bList.add(book);
			}while(rs.next());			
		}
		
		return bList;
	}
	
	public void delete(int book_id) throws Exception {
		conn = getConnetion();
		String sql = "delete from books where book_id = ?";
		
		pstmt = conn.prepareStatement(sql);
		pstmt.setInt(1, book_id);
		pstmt.executeUpdate();	
	}
}
